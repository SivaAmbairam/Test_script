import os
import random
import time
import json
import pandas as pd
from datetime import datetime
from bs4 import BeautifulSoup
from module_package import *
from DrissionPage import ChromiumPage, ChromiumOptions

def write_visited_log(url):
    output_dir = os.path.join('Output', 'temp')
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    file_path = os.path.join(output_dir, 'Visited_Carolina_urls.txt')
    with open(file_path, 'a', encoding='utf-8') as file:
        file.write(f'{url}\n')

def read_log_file():
    file_path = os.path.join('Output', 'temp', 'Visited_Carolina_urls.txt')
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as read_file:
            return read_file.read().split('\n')
    return []

def random_sleep(min_seconds=1, max_seconds=5):
    sleep_time = random.uniform(min_seconds, max_seconds)
    time.sleep(sleep_time)

if __name__ == '__main__':
    timestamp = datetime.now().date().strftime('%Y%m%d')
    file_name = 'Carolina Product'
    url = 'https://www.carolina.com/'
    base_url = 'https://www.carolina.com'
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'max-age=0',
        'Connection': 'keep-alive',
        'Host': 'www.carolina.com',
        'Referer': 'https://www.carolina.com/browse/product-search-results?Ntt=644402&Nr=OR%28product.type%3AProduct%29&tab=p&question=644402&searchExecByFormSubmit=true',
        'Sec-Ch-Device-Memory': '8',
        'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
        'Sec-Ch-Ua-Arch': '"x86"',
        'Sec-Ch-Ua-Full-Version-List': '"Not/A)Brand";v="8.0.0.0", "Chromium";v="126.0.6478.114", "Google Chrome";v="126.0.6478.114"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Model': '""',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
    }
    soup = get_soup(url, headers)
    content = soup.find('li', class_='nav-item c-nav-menu-link').find_all('li', class_='row c-nav-menu-l1')[1]
    inner_content = content.find('div', class_='c-nav-menu-subnav col-12 col-lg-7')
    product_category = inner_content.find('h3', class_='d-none d-lg-block').text.strip()
    if inner_content.find('ul', class_='row'):
        all_urls = inner_content.find('ul', class_='row').find('li')
        product_sub_category = all_urls.a.text.strip()
        main_url = f"{base_url}{all_urls.a['href']}"
        print(f'main_url -----------> {main_url}')
        random_sleep(1, 10)
        inner_request = get_soup(main_url, headers)
        inner_data = inner_request.find_all('div', class_='c-feature-product qv-model')
        for single_data in inner_data[:2]:
            product_url = f'{base_url}{single_data.find("a")["href"]}'
            print(product_url)
            random_sleep(1, 10)
            product_request = get_soup(product_url, headers)
            if product_request is None:
                continue
            content = product_request.find('script', type='application/ld+json')
            replace_content = str(content).replace('<script type="application/ld+json">', '').replace('</script>', '')
            json_content = json.loads(replace_content)
            for inner_json in json_content['offers']:
                '''PRICE'''
                try:
                    product_price = f"$ {inner_json['price']}"
                except:
                    product_price = ''
                '''PRODUCT URL'''
                try:
                    product_url = inner_json['url']
                except:
                    product_url = ''
                '''PRODUCT NAME'''
                try:
                    product_name = inner_json['name']
                    if re.search('Pack of \d+', str(product_name)):
                        product_quantity = re.search('Pack of \d+', str(product_name)).group().replace('Pack of', '').strip()
                    else:
                        product_quantity = 1
                except:
                    product_name = json_content['name']
                    product_quantity = '1'
                '''PRODUCT DESC'''
                try:
                    desc = inner_json['description']
                    desc_soup = BeautifulSoup(desc, 'html.parser').text.strip()
                    product_desc = BeautifulSoup(desc_soup, 'html.parser').text.strip()
                except:
                    desc = json_content['description']
                    desc_soup = BeautifulSoup(desc, 'html.parser').text.strip()
                    product_desc = BeautifulSoup(desc_soup, 'html.parser').text.strip()
                '''IMAGE URL'''
                try:
                    image_url = inner_json['image']
                except:
                    image_url = json_content['image']
                '''PRODUCT ID'''
                try:
                    product_id = inner_json['sku']
                except:
                    product_id = json_content['sku']
                if product_id in read_log_file():
                    continue
                print('current datetime------>', datetime.now())
                dictionary = {
                    'Carolina_product_category': product_category,
                    'Carolina_product_sub_category': product_sub_category,
                    'Carolina_product_id': product_id,
                    'Carolina_product_name': product_name,
                    'Carolina_product_quantity': product_quantity,
                    'Carolina_product_price': product_price,
                    'Carolina_product_url': product_url,
                    'Carolina_image_url': image_url,
                    'Carolina_product_desc': product_desc
                }
                articles_df = pd.DataFrame([dictionary])
                articles_df.drop_duplicates(subset=['Carolina_product_id', 'Carolina_product_name'], keep='first', inplace=True)
                output_dir = 'Output'
                if not os.path.exists(output_dir):
                    os.makedirs(output_dir)
                file_path = os.path.join(output_dir, f'{file_name}.csv')
                if os.path.isfile(file_path):
                    articles_df.to_csv(file_path, index=False, header=False, mode='a')
                else:
                    articles_df.to_csv(file_path, index=False)
                write_visited_log(product_id)
